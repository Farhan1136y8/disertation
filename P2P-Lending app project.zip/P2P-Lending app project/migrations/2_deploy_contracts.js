const Lending = artifacts.require("Lending");

module.exports = function(deployer) {
  deployer.deploy(Lending, "0xcf9447aD1E5be491C7f371b4375C660CDB2d5a23");
};
